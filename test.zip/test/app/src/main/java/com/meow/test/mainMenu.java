package com.meow.test;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class mainMenu extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);
    }
}